# Homework

- Create a Flink job that sessionizes the input data by IP address and host
- Use a 5 minute gap
- Answer these questions
  - What is the average number of web events of a session from a user on Tech Creator?
  - Compare results between different hosts (zachwilson.techcreator.io, zachwilson.tech, lulu.techcreator.io)