CREATE TABLE user_devices_cumulated (
    user_id NUMERIC PRIMARY KEY,
    device_activity_datelist JSONB
);
