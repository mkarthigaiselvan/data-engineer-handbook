CREATE TABLE hosts_cumulated_daily (
    host TEXT,
    host_activity_datelist DATE[],
    snapshot_date DATE
);
